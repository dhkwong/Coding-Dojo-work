package com.daryl.web.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class NumberGame
 */
@WebServlet("/")
public class NumberGame extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NumberGame() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if((Integer)session.getAttribute("random")!=null) {
        RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/views/NumberGame.jsp");//servlet route/file
		view.forward(request, response);
        }
        else {
        	int r = (int) (Math.random() * (101 - 0)) + 0;
        	session.setAttribute("toohigh", "display:none;");
        	session.setAttribute("win","display:none;");
        	session.setAttribute("toolow","display:none;");
        	session.setAttribute("winbutton", "display:none");
        	session.setAttribute("hidebutton", "");
        	session.setAttribute("random", r);
        	RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/views/NumberGame.jsp");//servlet route/file
    		view.forward(request, response);
        }
    	
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
