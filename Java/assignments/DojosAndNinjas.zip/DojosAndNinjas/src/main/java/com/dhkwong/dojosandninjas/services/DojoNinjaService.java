package com.dhkwong.dojosandninjas.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.dhkwong.dojosandninjas.models.Dojo;
import com.dhkwong.dojosandninjas.models.Ninja;
import com.dhkwong.dojosandninjas.repositories.DojoRepository;
import com.dhkwong.dojosandninjas.repositories.NinjaRepository;

@Service
public class DojoNinjaService {
	private final DojoRepository dojoRepository;
	private final NinjaRepository ninjaRepository;
	
	public DojoNinjaService(DojoRepository dojoRepository, NinjaRepository ninjaRepository) {
		this.dojoRepository = dojoRepository;
		this.ninjaRepository=ninjaRepository;
	}
	
	public List<Dojo> findAllDojos(){
		return dojoRepository.findAll();
	}
	public List<Ninja> findAllNinjas(){
		return ninjaRepository.findAll();
	}
	public Dojo createDojo(Dojo d) {
		return dojoRepository.save(d);
	}
	public Ninja createNinja(Ninja n) {
		return ninjaRepository.save(n);
	}
//	public List<Dojo> withoutNinja(){
//		
//		List<Ninja> allNinjas = findAllNinjas();
//		List<Dojo> allDojos = findAllDojos();
//		for(int i = 0 ; i< allNinjas.size();i++) {
//			for(int j = 0; j<allDojos.size();j++) {
//				if(allDojos.get(j).getNinjas().contains(allNinjas.get(i))) {
//					allDojos.remove(j);
//				}
//			}
//		}
//		return allDojos;
//		
//	}
//	public List<Person> withoutLicense(){
//		PersonService p = new PersonService(personrepo);
//		List<License> allLicense = findAllLicenses();
//		List<Person> allPeeps = p.findAllPeople();
//		for(int i = 0; i < allLicense.size(); i++) {
//		if (allPeeps.contains(allLicense.get(i).getPerson())) {
//			allPeeps.remove(allLicense.get(i).getPerson());
//		}
//		}
//		return allPeeps;
//	}

	public Dojo findDojoById(Long id) {
		Optional<Dojo> odojo = dojoRepository.findById(id);
		Dojo dojo = odojo.get();
		return dojo;
	}
	public Ninja findNinjaById(Long id) {
		Optional<Ninja> oninja = ninjaRepository.findById(id);
		Ninja ninja = oninja.get();
		return ninja;
	}
}
