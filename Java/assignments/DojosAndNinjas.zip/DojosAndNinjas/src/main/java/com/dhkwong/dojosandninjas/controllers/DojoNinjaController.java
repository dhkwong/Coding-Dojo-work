package com.dhkwong.dojosandninjas.controllers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dhkwong.dojosandninjas.models.Dojo;
import com.dhkwong.dojosandninjas.models.Ninja;
import com.dhkwong.dojosandninjas.services.DojoNinjaService;


@Controller
public class DojoNinjaController {
	private final DojoNinjaService djService;

	public DojoNinjaController(DojoNinjaService djService) {
		this.djService = djService;
	
	}

	@RequestMapping("/dojos/new")
	public String newDojo(@ModelAttribute("dojo")Dojo dojo) {
		return "newdojo.jsp";
	}
	@RequestMapping(value = "/dojos/new", method = RequestMethod.POST)
	public String createDojo(@Valid @ModelAttribute("dojo") Dojo dojo, BindingResult result) {
		if (result.hasErrors()) {
			return "/newdojo.jsp";
		} else {
			djService.createDojo(dojo);
			return "redirect:/dojos/new";
		}
	}

	@RequestMapping("/ninjas/new")
	public String newNinja(@ModelAttribute("ninja")Ninja ninja, Model model) {
		model.addAttribute("dojos", djService.findAllDojos());
		return "newninja.jsp";
	}
	@RequestMapping(value = "/ninjas/new", method = RequestMethod.POST)
	public String createNinja(@RequestParam("firstName") String firstName, @RequestParam("lastName") String lastName,
			@RequestParam("age") Integer age, @RequestParam("dojo") String dojoid) {
		Long did = Long.valueOf(dojoid);
		
		Dojo dojo = djService.findDojoById(did);//find dojo
		Ninja ninja = new Ninja(firstName, lastName, age, dojo);//create ninja
		djService.createNinja(ninja);//save ninja to db
		dojo.getNinjas().add(ninja);//add ninja to dojo
		djService.createDojo(dojo);//save updated to dojo, which updates
		return "redirect:/ninjas/new";
	}
	@RequestMapping("/dojos/{id}")
	public String show(Model model, @PathVariable("id") Long id) {
	
		model.addAttribute("dojo", djService.findDojoById(id));
		return "show.jsp";
	}
	

}














