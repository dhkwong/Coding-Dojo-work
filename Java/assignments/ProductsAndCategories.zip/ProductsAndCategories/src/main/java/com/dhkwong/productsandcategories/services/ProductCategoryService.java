package com.dhkwong.productsandcategories.services;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.dhkwong.productsandcategories.models.Category;
import com.dhkwong.productsandcategories.models.Product;
import com.dhkwong.productsandcategories.repositories.CategoryRepository;
import com.dhkwong.productsandcategories.repositories.ProductRepository;

@Service
public class ProductCategoryService {
	private final CategoryRepository cRepo;
	private final ProductRepository pRepo;

	public ProductCategoryService(CategoryRepository cRepo, ProductRepository pRepo) {
		this.cRepo = cRepo;
		this.pRepo = pRepo;
	}

	public List<Product> findAllProducts() {
		return pRepo.findAll();
	}

	public List<Category> findAllCategory() {
		return cRepo.findAll();
	}

	public Product createProduct(Product p) {
		return pRepo.save(p);
	}

	public Category createCategory(Category c) {
		return cRepo.save(c);
	}

	public Product updateProduct(Product p) {
		p.setUpdatedAt(new Date());
		return pRepo.save(p);
	}

	public Category updateCategory(Category c) {
		c.setUpdatedAt(new Date());
		return cRepo.save(c);
	}

	public Product findProductById(Long id) {
		Optional<Product> oproduct = pRepo.findById(id);
		return oproduct.get();// returns product type
	}

	public Category findCategoryById(Long id) {
		Optional<Category> oCategory = cRepo.findById(id);
		return oCategory.get();
	}
}
