package com.dhkwong.productsandcategories.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.dhkwong.productsandcategories.models.Product;

public interface ProductRepository extends CrudRepository<Product,Long> {
	List<Product> findAll();

}
