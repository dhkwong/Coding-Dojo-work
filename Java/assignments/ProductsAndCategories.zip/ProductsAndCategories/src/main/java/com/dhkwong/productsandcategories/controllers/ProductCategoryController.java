package com.dhkwong.productsandcategories.controllers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dhkwong.productsandcategories.models.Category;
import com.dhkwong.productsandcategories.models.Product;
import com.dhkwong.productsandcategories.services.ProductCategoryService;

@Controller
public class ProductCategoryController {
	private final ProductCategoryService pcService;

	public ProductCategoryController(ProductCategoryService pcService) {
		this.pcService = pcService;
	}

	@RequestMapping("/products/new")
	public String newProduct(@ModelAttribute("product") Product product) {
		return "newproduct.jsp";
	}

	@RequestMapping(value = "/products/new", method = RequestMethod.POST)
	public String processProduct(@ModelAttribute("product") Product product, BindingResult result) {
		if (result.hasErrors()) {
			return "newproduct.jsp";
		} else {
			pcService.createProduct(product);
			return "redirect:/products/new";
		}
	}

	@RequestMapping("/categories/new")
	public String newCategory(@ModelAttribute("category") Category category) {
		return "newcategory.jsp";
	}

	@RequestMapping(value = "/categories/new", method = RequestMethod.POST)
	public String processProduct(@ModelAttribute("category") Category category, BindingResult result) {
		if (result.hasErrors()) {
			return "newcategory.jsp";
		} else {
			pcService.createCategory(category);
			return "redirect:/categories/new";
		}
	}

	@RequestMapping("/categories/{id}")
	public String showCategory(@PathVariable("id") Long id, Model model) {
		model.addAttribute("category", pcService.findCategoryById(id));
		List<Product> categoryProducts = pcService.findCategoryById(id).getProducts();// get products in category
		List<Product> allProducts = pcService.findAllProducts();
		for (int i = 0; i < categoryProducts.size(); i++) {
			if (allProducts.contains(categoryProducts.get(i))) {
				allProducts.remove(categoryProducts.get(i));
			}
		}
		model.addAttribute("products", allProducts);
		return "showcategory.jsp";

	}

	@PostMapping("/addproduct")
	private String addProduct(@RequestParam("product") Long productId, @RequestParam("category") Long categoryId) {

		// get category and product objects to be modified
		Category category = pcService.findCategoryById(categoryId);
		Product newproduct = pcService.findProductById(productId);

		// get category's product list, add product to it
		List<Product> products = category.getProducts();
		products.add(newproduct);

		// set category's product list, update category
		category.setProducts(products);
		pcService.updateCategory(category);

		return "redirect:/categories/" + categoryId;
	}

	@RequestMapping("/products/{id}")
	private String showProduct(@PathVariable("id") Long id, Model model) {
		model.addAttribute("product", pcService.findProductById(id));
		List<Category> productcategories = pcService.findProductById(id).getCategories();
		List<Category> allcategories = pcService.findAllCategory();
		for (int i = 0; i < productcategories.size(); i++) {
			if (allcategories.contains(productcategories.get(i))) {
				allcategories.remove(productcategories.get(i));
			}
		}
		model.addAttribute("categories", allcategories);
		return "showproduct.jsp";

	}
	@PostMapping("/addcategory")
	private String addCategory(@RequestParam("category") Long categoryId, @RequestParam("product") Long productId) {
		Product product = pcService.findProductById(productId);
		Category category = pcService.findCategoryById(categoryId);
		
		List<Category> categories = product.getCategories();
		categories.add(category);
		
		product.setCategories(categories);
		
		pcService.updateProduct(product);
		
		return "redirect:/products/"+productId;
	}

}
