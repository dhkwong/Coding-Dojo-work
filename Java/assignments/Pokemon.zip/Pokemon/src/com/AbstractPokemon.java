package com;

public abstract class AbstractPokemon implements PokemonInterface{
	public Pokemon createPokemon(String name, int health, String type) {
		Pokemon pokemon = new Pokemon();
		pokemon.setHealth(health);
		pokemon.setName(name);
		pokemon.setType(type);
		return pokemon;
	}

}
