package com;

import java.util.ArrayList;

public class Pokedex extends AbstractPokemon {
	ArrayList<Pokemon> myPokemons;


	
	

	public void listPokemon() {
		// TODO Auto-generated method stub
	Pokemon bulbasaur = new Pokemon();
	bulbasaur.setName("bulbasaur");
	bulbasaur.setHealth(100);
	bulbasaur.setType("grass");
	myPokemons.add(bulbasaur);
	System.out.println(myPokemons);
		
	}
}
