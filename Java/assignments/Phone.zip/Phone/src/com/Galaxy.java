package com;

public class Galaxy extends Phone implements Ringable {
    public Galaxy(String versionNumber, int batteryPercentage, String carrier, String ringTone) {
        super(versionNumber, batteryPercentage, carrier, ringTone);// sets the super class's constructor attributes. not Galaxy's attributes
    }
    @Override
    public String ring() {
    	return getRingTone()
;        // your code here
    }
    @Override
    public String unlock() {
    	return("unlocking via fingerprint");
        // your code here
    	
    }
    @Override
    public void displayInfo() {
        // your code here     
    	System.out.println("Galaxy S9 from Verizon");
    }
}
