package com;

public interface Ringable {
	String ring();
	String unlock();
}
