package com.dhkwong.datetime;

import java.sql.Date;
import java.text.SimpleDateFormat;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller

public class HomeController {
	@RequestMapping("/date")
	public String Date(Model model) {
		SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date(System.currentTimeMillis());
		model.addAttribute("Date",formatter.format(date));
		return "Date.jsp";
	}
	@RequestMapping("/time")
	public String Time(Model model) {
		SimpleDateFormat formatter= new SimpleDateFormat( "HH:mm:ss");
		Date date = new Date(System.currentTimeMillis());
		model.addAttribute("Time",formatter.format(date));
	
		return "Time.jsp";
	}
}
