package com;

import java.util.Random;

public class BankAccount {
	private String accountnumber;
	private double checkingbalance=0;
	private double savingsbalance=0;
	public static int accountcount;
	public static int totalbalances; // increment on deposit
	private long tenaccnum = accountNumber();
	public BankAccount() {
		accountcount++;
	}

	private long accountNumber() {
		return (long)(Math.random()*100000 + 0000000000L);

	}
	public void depositCheckings(int money) {
		checkingbalance +=money;
		totalbalances+=money;
	}
	public void depositSavings(int money) {
		savingsbalance +=money;
		totalbalances+=money;
		System.out.println("savings: $"+savingsbalance);
	}
	public void withdrawCheckings(int money) {
		if(checkingbalance-money<=0) {
			System.out.println("Insufficient funds");
		}else {
			checkingbalance=-money;
			totalbalances-=money;
			
		}
	}
	public void displayMoney() {
		System.out.println("savings: $"+savingsbalance+ " checking: $"+checkingbalance);
	}
	public void displayTotal() {
		System.out.println("total: $"+totalbalances);
	}


}
