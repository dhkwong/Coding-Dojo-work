package com;

public class BankAccountTest {
	public static void main(String args[]) {
		BankAccount ba = new BankAccount();
		ba.depositCheckings(500);
		ba.depositSavings(600);
		ba.displayMoney();
		ba.displayTotal();
		BankAccount ba1 = new BankAccount();
		ba1.depositCheckings(300);
		ba1.depositSavings(1);
		ba1.withdrawCheckings(1500);
		ba1.displayMoney();
		ba1.displayTotal();
		
	}

}
