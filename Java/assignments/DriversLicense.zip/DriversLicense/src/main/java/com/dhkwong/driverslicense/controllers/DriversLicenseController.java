package com.dhkwong.driverslicense.controllers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dhkwong.driverslicense.models.License;
import com.dhkwong.driverslicense.models.Person;
import com.dhkwong.driverslicense.services.LicenseService;
import com.dhkwong.driverslicense.services.PersonService;

@Controller
public class DriversLicenseController {
	private final PersonService personService;
	private final LicenseService licenseService;

	public DriversLicenseController(PersonService personService, LicenseService licenseService) {
		this.licenseService = licenseService;
		this.personService = personService;
	}

	@RequestMapping("/persons/new")
	public String newPerson(@ModelAttribute("person") Person person) {
		return "/views/newperson.jsp";
	}

	@RequestMapping(value = "/persons/new", method = RequestMethod.POST)
	public String createPerson(@Valid @ModelAttribute("person") Person person, BindingResult result) {
		if (result.hasErrors()) {
			return "/views/newperson.jsp";
		} else {
			personService.createPerson(person);
			return "redirect:/persons/new";
		}

	}

	@RequestMapping("/licenses/new")
	public String newLicense(@Valid @ModelAttribute("license") License license, Model model) {
		model.addAttribute("persons", licenseService.withoutLicense());
		return "/views/newlicense.jsp";
	}

//	public String createLicense(@Valid @ModelAttribute("license") License license,@RequestParam("expirationDate") String edate, BindingResult result) {
	@RequestMapping(value = "/licenses/new", method = RequestMethod.POST)
	public String createLicense(@RequestParam("expirationDate") String edate, @RequestParam("state") String state,
			@RequestParam("person") String personid) {
		Long pid = Long.valueOf(personid);
		String pattern = "yyyy-mm-dd";
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		Date date = new Date();
		try {
			date = format.parse(edate);
			System.out.println("date: " + date);
		} catch (ParseException e) {
			System.out.println("error: " + e);
			return "redirect:/persons/new";

		}

		Person person = personService.findPersonById(pid);
		License newlicense = new License(person, state, date);
		licenseService.createLicense(newlicense);

//		License newlicense

		return "redirect:/licenses/new";

	}
	@RequestMapping("/persons/{id}")
	public String show(Model model, @PathVariable("id") Long id) {
	
		model.addAttribute("person", personService.findPersonById(id));
		return "views/show.jsp";
	}
	
}
