package com.dhkwong.driverslicense.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.dhkwong.driverslicense.models.Person;



public interface PersonRepository extends CrudRepository<Person, Long> {
	// for interface, these methods HAVE to be implemented. They are not the ONLY
	// functions available from CrudRepo
	// this method retrieves all the books from the database
	List<Person> findAll();
	
	// this method find a book by their description
//	    List<Language> findByDescriptionContaining(String search);
//	    // this method counts how many titles contain a certain string
//	    Long countByTitleContaining(String search);
//	    // this method deletes a book that starts with a specific title
//	    Long deleteByTitleStartingWith(String search);
}
