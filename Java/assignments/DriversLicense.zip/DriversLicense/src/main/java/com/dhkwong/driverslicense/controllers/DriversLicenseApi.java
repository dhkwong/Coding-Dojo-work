package com.dhkwong.driverslicense.controllers;

import java.util.Date;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dhkwong.driverslicense.models.License;
import com.dhkwong.driverslicense.models.Person;
import com.dhkwong.driverslicense.services.LicenseService;
import com.dhkwong.driverslicense.services.PersonService;

@RestController
public class DriversLicenseApi {
	private final LicenseService licenseService;
	private final PersonService personService;
	
	public DriversLicenseApi(PersonService personService, LicenseService licenseService) {
		this.licenseService = licenseService;
		this.personService= personService;
	}
	@RequestMapping("api/persons/new")
	public List<Person> getAllPeople() {
		return personService.findAllPeople();
	}
	@RequestMapping("api/licenses/new")
	public List<License> getAllLicenses() {
		return licenseService.findAllLicenses();
	}
	@RequestMapping(value="api/persons/new",method=RequestMethod.POST)
	public Person createPerson(@RequestParam("firstName") String firstname, @RequestParam("lastName") String lastname) {
		Person person = new Person(firstname, lastname);
		return personService.createPerson(person);
	}
	@RequestMapping(value = "api/licenses/new", method=RequestMethod.POST)
	public License createLicense(@RequestParam("person") Person person, @RequestParam("state") String state, @RequestParam("expirationDate")Date expirationDate) {
		License license = new License(person, state, expirationDate);
		return licenseService.createLicense(license);
		
	}

}
