package com.dhkwong.driverslicense.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.dhkwong.driverslicense.models.License;
import com.dhkwong.driverslicense.models.Person;
import com.dhkwong.driverslicense.repositories.LicenseRepository;
import com.dhkwong.driverslicense.repositories.PersonRepository;

@Service
public class LicenseService {
	private static String licensenumber = "000000";
	private final LicenseRepository licenseRepository;
	private final PersonRepository personrepo;

	public LicenseService(LicenseRepository licenseRepository, PersonRepository personrepo) {
		this.licenseRepository = licenseRepository;
		this.personrepo = personrepo;
	}

	public License addOneLicense(License license) {
		int licensenumber2 = Integer.parseInt(licensenumber);
		licensenumber2++;
		licensenumber = String.format("%06d", licensenumber2);
		
		license.setNumber(licensenumber);
		return licenseRepository.save(license);
	}
	public List<License> findAllLicenses() {
		return licenseRepository.findAll();
	}

	public License createLicense(License l) {	
		// license holds a person. use person.id to find person and the license to the person
		License newlicense = licenseRepository.save(l);
		newlicense = addOneLicense(newlicense); // updates license to have a license number instead of null
		Optional<Person> operson = personrepo.findById(newlicense.getPerson().getId());//find person
		Person person = operson.get();//get person from optional
		person.setLicense(newlicense);//set license to person
		personrepo.save(person);//save person after setting license
		return newlicense;

	}
	public List<Person> withoutLicense(){
		PersonService p = new PersonService(personrepo);
		List<License> allLicense = findAllLicenses();
		List<Person> allPeeps = p.findAllPeople();
		for(int i = 0; i < allLicense.size(); i++) {
		if (allPeeps.contains(allLicense.get(i).getPerson())) {
			allPeeps.remove(allLicense.get(i).getPerson());
		}
		}
		return allPeeps;
	}
}
