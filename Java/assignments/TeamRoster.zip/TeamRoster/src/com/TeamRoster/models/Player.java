package com.TeamRoster.models;

public class Player {
	public String firstName;
	public String lastName;
	public int age;
	
	public Player(String firstName, String lastName, int age) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		
	}
	public String getfirstName() {
		return this.firstName;
	}
	public String getlastName() {
		return this.lastName;
	}
	public int getAge() {
		return this.age;
	}


}
