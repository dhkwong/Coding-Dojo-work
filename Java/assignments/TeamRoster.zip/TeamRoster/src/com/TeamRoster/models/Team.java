package com.TeamRoster.models;

import java.util.ArrayList;

public class Team {
	public ArrayList<Player> players = new ArrayList<Player>();
	public String teamName = "";

	public Team(String teamName) {
		this.teamName = teamName;
	}

	public void insertPlayer(Player player) {
		players.add(player);
	}

	public void deletePlayer(int playerId) {
		players.remove(playerId);
	}

	public String getTeamName() {
		return this.teamName;
	}

	public int getTeamSize() {
		return this.players.size();
	}
	public ArrayList<Player> getPlayers() {
		return this.players;
	}
}
