package com.TeamRoster.models;

import java.util.ArrayList;

public class Roster {
	public static ArrayList<Team> teams = new ArrayList<Team>();
	
	public Roster() {
		
	}
	
	public void addTeam(Team team) {
		System.out.println("Hello");
		teams.add(team);	
		
	}
	
	public static void removeTeam(int teamId) {
		teams.remove(teamId);
	}
	
	public static ArrayList<Team> getTeams() {
		return teams;
	}

}
