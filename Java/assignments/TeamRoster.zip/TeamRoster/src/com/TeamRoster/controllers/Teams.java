package com.TeamRoster.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.TeamRoster.models.Roster;
import com.TeamRoster.models.Team;

/**
 * Servlet implementation class Teams
 */
@WebServlet("/Teams")
public class Teams extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Teams() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter("id") != null) {// if you have an ID, you're looking at a team
			request.setAttribute("team", Roster.getTeams().get(Integer.parseInt(request.getParameter("id")))); 
			request.setAttribute("teamid", request.getParameter("id"));
			System.out.println("team"+request.getAttribute("team"));						
			
			RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/TeamInfo.jsp");
			view.forward(request, response);

		} else {// otherwise, you're creating a new team
			RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/NewTeam.jsp");
			view.forward(request, response);
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter("teamName") != null) {// else if you have a teamname from a newly added team
			// redirect to home
			Roster roster = new Roster();
			String teamName = request.getParameter("teamName");
			Team team = new Team(teamName);
			roster.addTeam(team);
			System.out.println(roster);

			response.sendRedirect("/TeamRoster/Home");
			// TODO Auto-generated method stub
//			doGet(request, response);
		}
	}

}
