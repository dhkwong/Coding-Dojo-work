package com.TeamRoster.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.TeamRoster.models.Player;
import com.TeamRoster.models.Roster;


/**
 * Servlet implementation class Players
 */
@WebServlet("/Players")
//adds new player
public class Players extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Players() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//add new player
		if (request.getParameter("id") != null && request.getParameter("firstName")==null) {// if no id, you're making a player
			request.setAttribute("teamid", request.getParameter("id"));
			
			RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/NewPlayer.jsp");
			view.forward(request, response);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		if(request.getParameter("firstName" )!= null){
			
			String firstName = request.getParameter("firstName");
			String lastName = request.getParameter("lastName");
			int age = Integer.parseInt(request.getParameter("age"));
			// Create model
			
			Player player = new Player(firstName, lastName, age);
			System.out.println("New Player "+player);
			Roster.getTeams().get(Integer.parseInt(request.getParameter("id"))).insertPlayer(player);
			response.sendRedirect("/TeamRoster/Teams?id="+Integer.parseInt(request.getParameter("id")));
		}
		doGet(request, response);
	}

}
