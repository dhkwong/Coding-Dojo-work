package com.dhkwong.mvc.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.dhkwong.mvc.models.Book;
import com.dhkwong.mvc.services.BookService;

@Controller
public class BooksController {
private final BookService bookService; //calls an instance of bookservice to use, that is private and never changed
    
    public BooksController(BookService bookService) { //
        this.bookService = bookService;
    }
    
    @RequestMapping("/books") //route for user, not restful api
    public String index(Model model) {
        List<Book> books = bookService.allBooks();
        model.addAttribute("books", books);
        return "/books/index.jsp";
    }
    @RequestMapping("/books/new") //path to display form for new book
    public String newBook(@ModelAttribute("book") Book book) {
        return "/books/new.jsp";
    }
    @RequestMapping(value="/books", method=RequestMethod.POST) //path takes and processes POST form data
    public String create(@Valid @ModelAttribute("book") Book book, BindingResult result) { 
        if (result.hasErrors()) {
            return "/books/new.jsp";
        } else {
            bookService.createBook(book);
            return "redirect:/books";
        }
    }
    @RequestMapping("/books/{id}") //path to display form for new book
    public String show(@PathVariable("id") Long id, Model model) {
    	Book book = bookService.findBook(id);
    	model.addAttribute("book",book);
        return "/books/show.jsp";
    }
}
