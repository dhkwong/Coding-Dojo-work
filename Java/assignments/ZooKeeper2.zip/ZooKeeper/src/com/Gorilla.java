package com;

public class Gorilla extends Mammal {
	public Gorilla(int energylevel) {
		this.setEnergylevel(energylevel);
		
	}

	public void throwSomething() {
		System.out.println("I've thrown something");
		this.setEnergylevel(this.displayEnergy()-5);
		this.displayEnergy();
		
	}
	public void eatBanana() {
		System.out.println("I've eaten a banana");
		this.setEnergylevel(this.displayEnergy()+10);
		this.displayEnergy();
	}
	public void climbTree() {
		System.out.println("I've climbed a tree");
		this.setEnergylevel(this.displayEnergy()-10);
		this.displayEnergy();
	}
}
