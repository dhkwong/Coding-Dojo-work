package com;

public class Bat extends Mammal{
	public Bat() {
		this.setEnergylevel(300);
		
	}
	public void fly() {
		System.out.println("flying...");
		this.setEnergylevel(this.displayEnergy()-50);
		this.displayEnergy();
		
	}
	public void eatHumans() {
		System.out.println("eating people...");
		this.setEnergylevel(this.displayEnergy()+25);
		this.displayEnergy();
		
	}
	public void attackTown() {
		System.out.println("terrorizing town");
		this.setEnergylevel(this.displayEnergy()-100);
		this.displayEnergy();
		
	}

}
