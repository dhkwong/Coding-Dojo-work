package com;
import com.characters.*;
public class HumanTest {
	public static void main(String args[]) {
		Human human = new Human();
		Human human1 = new Human();
		human.attackHuman(human1);
		Ninja ninja = new Ninja();
		ninja.steal(human1);
		Samurai samurai = new Samurai();
		Samurai samurai1 = new Samurai();
		samurai.deathBlow(human1);
		samurai.meditate();
		Wizard wizard = new Wizard();
		wizard.fireball(samurai);
		wizard.heal(human1);
		samurai1.howMany();

	}

}
