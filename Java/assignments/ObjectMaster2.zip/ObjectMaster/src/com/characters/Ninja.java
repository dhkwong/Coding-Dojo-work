package com.characters;
import com.Human;

public class Ninja extends Human{
	public Ninja() {
		this.setStealth(10);
		
	}
	public void steal(Human human) {
		human.setHealth(human.getHealth()-getStealth());
		System.out.println("stealing from human. His health is: "+ human.getHealth());
		setHealth(getHealth()+getStealth());
		System.out.println("my health is: "+ getHealth());
		
	}
	public void runAway() {
		setHealth(getHealth()-10);
		System.out.println("Running away. My health is: "+ getHealth());
	}

}
