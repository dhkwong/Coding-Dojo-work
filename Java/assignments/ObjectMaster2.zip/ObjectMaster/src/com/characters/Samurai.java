package com.characters;
import com.Human;
public class Samurai extends Human{
	public static int numberofobjects=0;
	public Samurai() {
		this.setHealth(200);
		numberofobjects++;
	}
	public void deathBlow(Human human) {
		human.setHealth(0);
		System.out.println("killed person");
		
		setHealth(getHealth()/2);
		System.out.println("Health is: "+getHealth());
	}
	public void meditate() {
		System.out.println("Health is: "+getHealth());
		setHealth(getHealth()+(getHealth()/2));
		System.out.println("Health is: "+getHealth()+ "after meditating");
	}
	public void howMany() {
		System.out.println("there are "+numberofobjects+" samurai");
	}

}
