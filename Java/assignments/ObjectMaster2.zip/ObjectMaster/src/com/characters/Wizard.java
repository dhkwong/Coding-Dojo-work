package com.characters;

import com.Human;

public class Wizard extends Human{
	public Wizard() {
		setIntelligence(8);
		setHealth(50);
	}
	public void heal(Human human) {
		human.setHealth(human.getHealth()+this.getIntelligence());
		System.out.println("Healing human. His health is: "+ human.getHealth());
	}
	public void fireball(Human human) {
		human.setHealth(human.getHealth()-(this.getIntelligence()*3));
		System.out.println("Fireballing human. His health is: "+ human.getHealth());
	}

}
