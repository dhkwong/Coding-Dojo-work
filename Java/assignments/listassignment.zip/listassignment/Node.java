public class Node {
    public int value;
    public Node next;

    public Node(int value) {
        // your code here
        this.value = value;
    }

}