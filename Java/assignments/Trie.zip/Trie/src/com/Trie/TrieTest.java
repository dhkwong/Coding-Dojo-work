package com.Trie;
import java.util.Set;
public class TrieTest {
    public static void main(String[] args) {
        Trie trie = new Trie();
        trie.insertWord("car");
        trie.insertWord("card");
        trie.insertWord("chip");
        trie.insertWord("trie");
        trie.insertWord("try");
        System.out.println(trie.isPrefixValid("car"));
//        Set<Character> keys = trie.root.children.keySet();
//        for(Character key: keys) {
//        	System.out.println(key);
//        	Set <Character> keys1 = trie.root.children.get(key).children.keySet();
//        for(Character key1: keys1) {
//        	System.out.println(key1);
//        }
//        }
//        
//        Set <Character> keys2 = trie.root.children.get('c').children.keySet();
//        for(Character key: keys2) {
//        	System.out.println(key);
//        }
    }
}
