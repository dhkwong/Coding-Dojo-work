package com.dhkwong.languages.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.dhkwong.languages.models.Language;
import com.dhkwong.languages.repositories.LanguageRepository;

@Service
public class LanguageService {
	private final LanguageRepository languageRepository;

	public LanguageService(LanguageRepository languageRepository) {
		this.languageRepository = languageRepository;
	}

	public List<Language> allLanguages() {
		return languageRepository.findAll();
	}

// creates a language
	public Language createLanguage(Language b) { // saves language into repo.
		return languageRepository.save(b);
	}

// retrieves a language
	public Language findLanguage(Long id) {
		Optional<Language> optionalLanguage = languageRepository.findById(id);
		if (optionalLanguage.isPresent()) {
			return optionalLanguage.get();
		} else {
			return null;
		}
	}

	public Language updateLanguage(Language b) {// takes form data set into language from LanguagesApi

		return languageRepository.save(b);

	}

	public void deleteLanguage(Long id) {
		languageRepository.deleteById(id);

	}
}
