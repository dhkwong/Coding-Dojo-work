package com.dhkwong.lookify.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.dhkwong.lookify.models.Song;

public interface SongRepository extends CrudRepository<Song, Long> {
	// for interface, these methods HAVE to be implemented. They are not the ONLY
	// functions available from CrudRepo
	// this method retrieves all the books from the database
	List<Song> findAll();

	// this method find a book by their description
//    List<Language> findByDescriptionContaining(String search);
//    // this method counts how many titles contain a certain string
	List<Song> findByArtistContaining(String search); //queries ARTISTS field "artist" by string
	List<Song> findTop10ByOrderByRatingDesc();
//    // this method deletes a book that starts with a specific title
//    Long deleteByTitleStartingWith(String search);
}