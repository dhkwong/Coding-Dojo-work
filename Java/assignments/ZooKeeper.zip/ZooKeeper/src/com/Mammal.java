package com;

public class Mammal {
	private int energylevel;

	public int displayEnergy() {
		System.out.println(this.energylevel);
		return energylevel;
	}

	public void setEnergylevel(int energylevel) {
		this.energylevel = energylevel;
	}
	
	

}
