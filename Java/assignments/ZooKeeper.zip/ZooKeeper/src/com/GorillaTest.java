package com;

public class GorillaTest {
	public static void main(String args[]) {
		Gorilla gorilla = new Gorilla(100);
		gorilla.throwSomething();
		gorilla.eatBanana();
		gorilla.climbTree();
	}

}
