package com.dhkwong.mvc.services;

import java.util.List;
import java.util.Optional;
import java.util.*;

import org.springframework.stereotype.Service;

import com.dhkwong.mvc.models.Book;
import com.dhkwong.mvc.repositories.BookRepository;

@Service
public class BookService {
	private final BookRepository bookRepository;

	public BookService(BookRepository bookRepository) {// constructor setting up service. like httpservice in MEAN
														// controller=> DB/model
		this.bookRepository=bookRepository;

	}
	public List<Book> allBooks() {
        return bookRepository.findAll();
    }
    // creates a book
    public Book createBook(Book b) { //saves book into repo. Also is how you update
        return bookRepository.save(b);
    }
    // retrieves a book
    public Book findBook(Long id) {
        Optional<Book> optionalBook = bookRepository.findById(id);
        if(optionalBook.isPresent()) {
            return optionalBook.get();
        } else {
            return null;
        }
    }
    public Book updateBook(Book b) {
//    	Optional<Book> optionalBook = bookRepository.findById(id);
//    	if(optionalBook.isPresent()) {
//            return optionalBook.get();
//        } else {
//            return null;
//        }
    	return bookRepository.save(b);
    	
    }
    public void deleteBook(Long id) {
    	bookRepository.deleteById(id);
    	
    }

}
