package com.dhkwong.javabeltexam.controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dhkwong.javabeltexam.models.Idea;
import com.dhkwong.javabeltexam.models.User;
import com.dhkwong.javabeltexam.services.UserIdeaService;
import com.dhkwong.javabeltexam.validator.UserValidator;

@Controller
public class UserIdeaController {
	private final UserIdeaService uiService;
	private final UserValidator userValidator;

	public UserIdeaController(UserIdeaService uiService, UserValidator userValidator) {
		this.uiService = uiService;
		this.userValidator = userValidator;

	}

	@RequestMapping("/")
	public String registerForm(@ModelAttribute("user") User user) {
		return "loginreg.jsp";
	}

	@RequestMapping(value = "/registration", method = RequestMethod.POST)
	public String registerUser(@Valid @ModelAttribute("user") User user, BindingResult result, HttpSession session,
			Model model) {
		userValidator.validate(user, result);
		if (result.hasErrors()) {
			return "loginreg.jsp";
		} else if (uiService.findByEmail(user.getEmail()) != null) {
			model.addAttribute("regerror", "User already exists!");
			return "loginreg.jsp";
		}
		User u = uiService.registerUser(user);
		session.setAttribute("userid", u.getId());
		return "redirect:/ideas";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String loginUser(@RequestParam("email") String email, @RequestParam("password") String password, Model model,
			HttpSession session) {

		if (uiService.authenticateUser(email, password)) { // if true, set session
			session.setAttribute("userid", uiService.findByEmail(email).getId());
			return "redirect:/ideas";
		} else {

			model.addAttribute("error", "invalid login");
			return "loginreg.jsp";
		}

	}

	@RequestMapping("/ideas")
	public String home(HttpSession session, Model model) {
		// get user from session, save them in the model and return the home page
		System.out.println(session.getAttribute("userid"));
		if (session.getAttribute("userid").equals(null)) {// if someone is NOT already logged in
			return "redirect:/";// go back to login
		} else {
			User user = uiService.findUserById((Long) session.getAttribute("userid"));
			model.addAttribute("user", user);// pulls user
			model.addAttribute("ideas", uiService.findAllIdeas());

			return "ideas.jsp"; // else, they're logged in and we can show them theor events homepage
		}

	}

	@RequestMapping("/newidea")
	public String newIdea(@Valid @ModelAttribute("ideaModel") Idea idea) {
		return "newidea.jsp";
	}

	@RequestMapping(value = "/newidea", method = RequestMethod.POST)
	public String createIdea(@Valid @ModelAttribute("ideaModel") Idea idea, BindingResult result, HttpSession session) {
		User user = uiService.findUserById((Long) session.getAttribute("userid"));
		if (result.hasErrors()) {
			System.out.println("idea creation has errors");
			return "newidea.jsp";
		} else {
			idea.setCreator(user);
			uiService.createIdea(idea);
			return "redirect:/ideas";
		}
	}

	@RequestMapping("/like/{id}")
	public String likeIdea(@PathVariable("id") Long id, HttpSession session) {
		Idea idea = uiService.findIdeaById(id);
		User user = uiService.findUserById((Long) session.getAttribute("userid"));
		idea.getLikes().add(user);
		uiService.updateIdea(idea);
		return "redirect:/ideas";
	}

	@RequestMapping("/unlike/{id}")
	public String unlikeIdea(@PathVariable("id") Long id, HttpSession session) {
		Idea idea = uiService.findIdeaById(id);
		User user = uiService.findUserById((Long) session.getAttribute("userid"));
		idea.getLikes().remove(user);
		uiService.updateIdea(idea);
		return "redirect:/ideas";
	}

	@RequestMapping("ideas/{id}")
	public String showIdea(@PathVariable("id") Long id, HttpSession session, Model model) {
		Idea idea = uiService.findIdeaById(id);
		User user = uiService.findUserById((Long) session.getAttribute("userid"));
		model.addAttribute("idea", idea);
		model.addAttribute("user", user);
		return "showidea.jsp";
	}

	@RequestMapping("/edit/{id}")
	public String edit(@Valid @ModelAttribute("ideaModel") Idea idea, @PathVariable("id") Long id, HttpSession session,
			Model model) {
		User user = uiService.findUserById((Long) session.getAttribute("userid"));
		if (uiService.findIdeaById(id).getCreator().equals(user)) {
			model.addAttribute("idea", uiService.findIdeaById(id));
			return "editidea.jsp";

		} else {
			return "redirect:/ideas";
		}
	}

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.POST)
	public String editingIdea(@Valid @ModelAttribute("ideaModel") Idea idea, BindingResult result, @PathVariable("id") Long id,
			HttpSession session, Model model) {
		
		User user = uiService.findUserById((Long) session.getAttribute("userid"));
		if(result.hasErrors()) {
			System.out.println("idea editing has errors");
			model.addAttribute("idea", uiService.findIdeaById(id));
			return "editidea.jsp";
		}else {
		idea.setCreator(user);
		idea.setLikes(uiService.findIdeaById(id).getLikes()); 
		uiService.updateIdea(idea);
		return "redirect:/ideas/"+id;
		}
	}
	@RequestMapping("/delete/{id}")
	public String deleteIDea(@PathVariable("id") Long id, HttpSession session) {
		User user = uiService.findUserById((Long) session.getAttribute("userid"));
		if(uiService.findIdeaById(id).getCreator().equals(user)) {
			uiService.deleteIdea(uiService.findIdeaById(id));
			return "redirect:/ideas";
		}else {
			return "redirect:/ideas";
		}
		
	}
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";

	}
}
