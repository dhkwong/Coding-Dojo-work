package com.dhkwong.javabeltexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaBeltExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaBeltExamApplication.class, args);
	}

}
