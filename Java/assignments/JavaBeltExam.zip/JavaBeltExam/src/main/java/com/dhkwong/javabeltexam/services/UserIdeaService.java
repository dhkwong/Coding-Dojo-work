package com.dhkwong.javabeltexam.services;

import java.util.List;
import java.util.Optional;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.stereotype.Service;

import com.dhkwong.javabeltexam.models.Idea;
import com.dhkwong.javabeltexam.models.User;
import com.dhkwong.javabeltexam.repositories.IdeaRepository;
import com.dhkwong.javabeltexam.repositories.UserRepository;

@Service
public class UserIdeaService {
	private final IdeaRepository ideaRepo;
	private final UserRepository userRepo;

	public UserIdeaService(IdeaRepository ideaRepo, UserRepository userRepo) {
		this.ideaRepo = ideaRepo;
		this.userRepo = userRepo;
	}

	public User registerUser(User user) {
		String hashed = BCrypt.hashpw(user.getPassword(), BCrypt.gensalt());
		user.setPassword(hashed);
		return userRepo.save(user);

	}

	public boolean authenticateUser(String email, String password) {
		User user = userRepo.findByEmail(email);
		if (user == null) {
			return false;
		} else {
			if (BCrypt.checkpw(password, user.getPassword())) {
				return true;
			} else {
				return false;
			}
		}

	}

	public List<User> findAllUsers() {
		return userRepo.findAll();
	}

	public User findByEmail(String email) {
		return userRepo.findByEmail(email);
	}

	public User findUserById(Long id) {
		Optional<User> ouser = userRepo.findById(id);
		if (ouser.isPresent()) {
			return ouser.get();

		} else {
			return null;
		}
	}

	public User createUser(User user) {
		return userRepo.save(user);
	}

	public User updateUser(User user) {
		return userRepo.save(user);
	}


//Idea Services

public List<Idea> findAllIdeas(){
	return ideaRepo.findAll();
}
public Idea findIdeaById(Long id) {
	Optional<Idea> oidea = ideaRepo.findById(id);
	return oidea.get();
}

public Idea createIdea(Idea idea) {
	return ideaRepo.save(idea);
}

public Idea updateIdea(Idea idea) {
	return ideaRepo.save(idea);
}
public void deleteIdea(Idea idea) {
	ideaRepo.delete(idea);
}






}
























