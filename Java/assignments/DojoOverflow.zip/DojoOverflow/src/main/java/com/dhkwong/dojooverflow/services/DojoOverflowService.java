package com.dhkwong.dojooverflow.services;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.dhkwong.dojooverflow.models.Answer;
import com.dhkwong.dojooverflow.models.Question;
import com.dhkwong.dojooverflow.models.Tag;
import com.dhkwong.dojooverflow.repositories.AnswerRepository;
import com.dhkwong.dojooverflow.repositories.QuestionRepository;
import com.dhkwong.dojooverflow.repositories.TagRepository;

@Service
public class DojoOverflowService {
	private final QuestionRepository qrepo;
	private final TagRepository trepo;
	private final AnswerRepository arepo;

	public DojoOverflowService(QuestionRepository qrepo, TagRepository trepo, AnswerRepository arepo) {
		this.qrepo = qrepo;
		this.trepo = trepo;
		this.arepo = arepo;
	}

	//Question Service Methods
	public List<Question> findAllQuestions() {
		return qrepo.findAll();
	}
	
	public Question findQuestionById(Long id) {
		Optional<Question> oQuestion = qrepo.findById(id);
		return 	oQuestion.get();
	}
	public Question createQuestion(Question q) {
		return qrepo.save(q);
	}
	public Question updateQuestion(Question q) {
		q.setUpdatedAt(new Date());
		return qrepo.save(q);
	}
	//Tag Service Methods
	public List<Tag> findAllTags(){
		return trepo.findAll();
	}
	public Tag findTagById(Long id) {
		Optional<Tag> oTag = trepo.findById(id);
		return oTag.get();
	}
	public Tag findTagBySubject(String subject) {
		return trepo.findBySubject(subject);
	}
	public Tag createTag(Tag t) {
		return trepo.save(t);
	}
	public Tag updateTag(Tag t) {
		t.setUpdatedAt(new Date());
		return trepo.save(t);
	}
	//Answer Service Methods
	public List<Answer> findAllAnswers(){
		return arepo.findAll();
	}
	public Answer findAnswerById(Long id) {
		Optional<Answer> oAnswer = arepo.findById(id);
		return oAnswer.get();
	}
	public Answer createAnswer(Answer a) {
		return arepo.save(a);
	}
	public Answer updateAnswer(Answer a) {
		
		return arepo.save(a);
	}
	
}








