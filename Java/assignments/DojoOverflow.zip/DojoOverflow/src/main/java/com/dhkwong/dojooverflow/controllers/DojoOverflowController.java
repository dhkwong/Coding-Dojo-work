package com.dhkwong.dojooverflow.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dhkwong.dojooverflow.models.Answer;
import com.dhkwong.dojooverflow.models.Question;
import com.dhkwong.dojooverflow.models.Tag;
import com.dhkwong.dojooverflow.services.DojoOverflowService;


@Controller
public class DojoOverflowController {
	DojoOverflowService doService;

	public DojoOverflowController(DojoOverflowService doService) {
		this.doService = doService;
	}

	@RequestMapping("/questions")
	public String home(Model model) {
		model.addAttribute("questions", doService.findAllQuestions());
		return "home.jsp";
	}

	@RequestMapping("/questions/new") // show new question form
	public String newQuestionPage(@ModelAttribute("question") Question question, Model model) {

		return "newquestion.jsp";
	}

	@PostMapping("/questions/new") // process post new question and tags
	public String createQuestion(@RequestParam("question") String question, @RequestParam("tags") String tags) {

		Question newQuestion = new Question(question);

		String[] tagList = tags.split(",");
		if (tags.length() > 0) {
			if (tagList.length > 3) {
				return "redirect:/questions/";
			}

			List<Tag> allTags = new ArrayList<>();
			for (String tag : tagList) {
				Tag newtag;
				if (doService.findTagBySubject(tag) == null) { // if tag doesn't exist, create new tag and save into
																// newtag variable
					newtag = new Tag(tag);
					doService.createTag(newtag);
					newtag = doService.findTagById(newtag.getId());
				} else {// else tag pre-exists and I find the Tag by subject to insert into Question.
					newtag = doService.findTagBySubject(tag);
				}
				allTags.add(newtag);

			}
			newQuestion.setTags(allTags);
		}
		doService.createQuestion(newQuestion);
		return "redirect:/questions";
	}

	// show question page
	@RequestMapping("/questions/{id}")
	public String showQuestion(@PathVariable("id") Long questionId, @ModelAttribute("answerModel") Answer answer,
			Model model) {
		Question question = doService.findQuestionById(questionId);
		
		model.addAttribute("question", question);
		return "showquestion.jsp";
	}

	// process Answer post on show Question page
	@RequestMapping(value="/questions/{id}", method= RequestMethod.POST)
	public String createAnswer(@Valid @ModelAttribute("answerModel") Answer answerModel, BindingResult result,
			@PathVariable("id") Long questionId) {
		if (result.hasErrors()) {
			System.out.println(answerModel);
			return "showquestion.jsp";
		} else {
//			question.getAnswer().add(answer);
//			doService.updateQuestion(question);
			
			Question question =doService.findQuestionById(questionId);
			answerModel.setQuestion(question);
			doService.createAnswer(answerModel);
			return "redirect:/questions/" + questionId;
		}

	}
	
//	@PostMapping("/question/{id}")
//	public String createAnswer(@RequestParam("answer") String answer, @PathVariable("id") Long questionId) {
//		Question question = doService.findQuestionById(questionId);
//		Answer newanswer = new Answer(answer);
//		doService.createAnswer(newanswer);
//		question.getAnswer().add(newanswer);
//		doService.updateQuestion(question);
//		return "redirect:/questions/" + questionId;
//
//	}
	
//	@RequestMapping(value = "/ninjas/new", method = RequestMethod.POST)
//	public String createNinja(@RequestParam("firstName") String firstName, @RequestParam("lastName") String lastName,
//			@RequestParam("age") Integer age, @RequestParam("dojo") String dojoid) {
//		Long did = Long.valueOf(dojoid);
//		
//		Dojo dojo = djService.findDojoById(did);//find dojo
//		Ninja ninja = new Ninja(firstName, lastName, age, dojo);//create ninja
//		djService.createNinja(ninja);//save ninja to db
//		dojo.getNinjas().add(ninja);//add ninja to dojo
//		djService.createDojo(dojo);//save updated to dojo, which updates
//		return "redirect:/ninjas/new";
//	}

}
