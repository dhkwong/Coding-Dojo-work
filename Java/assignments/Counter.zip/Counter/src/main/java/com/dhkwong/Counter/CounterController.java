package com.dhkwong.Counter;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller

@RequestMapping("/your_server")
public class CounterController {
	@RequestMapping("")

	public String yourServer(HttpSession session) {
		if (session.getAttribute("count") == null) {
			session.setAttribute("count", 0);

		} else {
			Integer count = (Integer) session.getAttribute("count");
			count++;
			session.setAttribute("count", count);
		}

		return "server.jsp";
	}

	@RequestMapping("/counter")
	public String counter(HttpSession session) {
		if (session.getAttribute("count") == null) {
			session.setAttribute("count", 0);

		}

		return "counter.jsp";

	}
}
