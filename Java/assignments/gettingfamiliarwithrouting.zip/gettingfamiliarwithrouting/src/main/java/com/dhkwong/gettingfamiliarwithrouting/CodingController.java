package com.dhkwong.gettingfamiliarwithrouting;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/coding")
public class CodingController {
	@RequestMapping("")
	public String hello() {
		// requires ?q= attached at the end for a query
		return "Hello coding dojo";
	}
	@RequestMapping("/python")
	public String python() {
		// requires ?q= attached at the end for a query
		return "Python/Django was awesome...";
	}
	@RequestMapping("/java")
	public String java() {
		// requires ?q= attached at the end for a query
		return "Java is better";
	}

	
}
