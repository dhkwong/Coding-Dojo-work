package com.dhkwong.gettingfamiliarwithrouting;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class DojoController {
	

	@RequestMapping("/{location}")
	

		public String dojo(@PathVariable("location") String location) {
			// requires ?q= attached at the end for a query
			if (location.equals("dojo")) {
				return "The dojo is awesome!";
			}
			if (location.equals("burbank-dojo")) {
				return location + "Burbank Dojo is located in Southern California";
			}
			if (location.equals("sanjose")) {
				return location + "SJ dojo is the headquarters";
			}
			return location;
		}

	
}
