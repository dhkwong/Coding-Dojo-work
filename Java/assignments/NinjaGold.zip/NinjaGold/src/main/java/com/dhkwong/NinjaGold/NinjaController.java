package com.dhkwong.NinjaGold;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import java.util.*;


@Controller

public class NinjaController {

	@RequestMapping("/")
	public String index(HttpSession session) {
		if(session.getAttribute("totalgold")==null) {
			session.setAttribute("totalgold", 0);//initialize gold
		}
		if(session.getAttribute("activities")==null) {
			session.setAttribute("activities", "");
		}
		return "ninjagold.jsp";
	}
	@RequestMapping(value="/process_money", method = RequestMethod.POST)
	public String process(HttpSession session, @RequestParam("getgold") String getgold) {
		if(getgold.equals("farm")) {
			int gold = (int) session.getAttribute("totalgold");
			gold+=(Math.random() * ((20 - 10) + 1)) + 10;
			session.setAttribute("totalgold", gold);
			String appending = (String) session.getAttribute("activities");
			appending += "you've added "+gold;
			session.setAttribute("activities", appending);
			return "redirect:/";
			
		}
		else if(getgold.equals("cave")) {
			int gold = (int) session.getAttribute("totalgold");
			gold+=(Math.random() * ((10 - 5) + 1)) + 5;
			session.setAttribute("totalgold", gold);
			String appending = (String) session.getAttribute("activities");
			appending += "you've added "+gold;
			session.setAttribute("activities", appending);
			return "redirect:/";
			
		}
		else if(getgold.equals("house")) {
			int gold = (int) session.getAttribute("totalgold");
			gold+=(Math.random() * ((5 - 2) + 1)) + 2;
			session.setAttribute("totalgold", gold);
			String appending = (String) session.getAttribute("activities");
			appending += "you've added "+gold;
			session.setAttribute("activities", appending);
			return "redirect:/";
			
			
		}
		else if (getgold.equals("casino")) {
			int gold = (int) session.getAttribute("totalgold");
			gold+=(Math.random() * ((50 - -50) + 1)) + -50;
			session.setAttribute("totalgold", gold);
			String appending = (String) session.getAttribute("activities");
			if(gold>=0) {
			appending += "you've added "+gold;
			}
			else {
				appending += "you've subtracted "+gold;
			
			}
			session.setAttribute("activities", appending);
			return "redirect:/";
			
		}
		
		return "redirect:/";
	}
	
	@RequestMapping("/d")
	public String delete(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
	
	

}
