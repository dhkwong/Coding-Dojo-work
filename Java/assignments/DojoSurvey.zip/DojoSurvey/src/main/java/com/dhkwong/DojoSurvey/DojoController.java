package com.dhkwong.DojoSurvey;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DojoController {
	@RequestMapping("/")
	public String home() {
		return "index.jsp";
	}

	@RequestMapping(value = "/result", method = RequestMethod.POST)
	public String process(Model model, @RequestParam("name") String name, @RequestParam("location") String location,
			@RequestParam("language") String language, @RequestParam("comments") String comments) {
		model.addAttribute("name", name).addAttribute("location", location).addAttribute("language", language)
				.addAttribute("comments", comments);
		return "result.jsp";

	}


}
