package com.characters;

public class Wizard {

}
