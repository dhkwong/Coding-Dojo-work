package com;

public class Human {
	private int strength=3;
	private int intelligence=3;
	private int health = 100;
	public Human() {
		
	}
	public int getIntelligence() {
		return intelligence;
	}
	public void setIntelligence(int intelligence) {
		this.intelligence = intelligence;
	}
	public int getStrength() {
		return strength;
	}
	public void setStrength(int strength) {
		this.strength = strength;
	}
	public int getHealth() {
		return health;
	}
	public void setHealth(int health) {
		this.health = health;
	}
	public void attackHuman(Human human) {
		System.out.println("attacking human");
		human.setHealth(human.getHealth()-this.getStrength());
		System.out.println("attacked human's new health: "+human.getHealth());
		
	}
}
