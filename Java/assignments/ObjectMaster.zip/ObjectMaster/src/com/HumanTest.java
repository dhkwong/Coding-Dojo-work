package com;

public class HumanTest {
	public static void main(String args[]) {
		Human human = new Human();
		Human human1 = new Human();
		human.attackHuman(human1);
	}

}
