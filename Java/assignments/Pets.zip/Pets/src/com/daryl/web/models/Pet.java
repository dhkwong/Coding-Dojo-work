package com.daryl.web.models;

public interface Pet {
	String showAffection();

}
