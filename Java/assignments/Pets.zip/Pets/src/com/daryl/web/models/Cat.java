package com.daryl.web.models;

public class Cat extends Animal implements Pet {

	public Cat(String name, String breed, int weight) {
		super(name, breed, weight);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String showAffection() {
		// TODO Auto-generated method stub
		return "I'm a cat. My name is: " + name + " my breed is: " + breed + "and my weight is: "+weight;
	} 

}
