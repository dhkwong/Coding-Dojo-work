package com.daryl.web.models;

public class Animal {
	String name;
	String breed;
	int weight;
	public Animal(String name, String breed, int weight) {
		this.name=name;
		this.breed = breed;
		this.weight = weight;
	}

}
