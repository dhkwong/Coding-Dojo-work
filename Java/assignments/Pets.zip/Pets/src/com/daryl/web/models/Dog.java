package com.daryl.web.models;

public class Dog extends Animal implements Pet {

	public Dog(String name, String breed, int weight) {
		super(name, breed, weight);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String showAffection() {
		if(weight<10) {
			return "I'm a dog. My name is: " + name + " my breed is: " + breed + "and my weight is: "+weight;
		}
		else {
			return "I'm a cat. My name is: " + name + " my breed is: " + breed + "I'm a big boi, and my weight is: "+weight;
		}

	}

}
