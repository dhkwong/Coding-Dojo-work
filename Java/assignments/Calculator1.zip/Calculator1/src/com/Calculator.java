package com;

public class Calculator {
	private Double operandone;
	private Double operandtwo;
	private Character operation;
	private Double total;
	
	public void setOperandOne(Double num) {
		this.operandone = num;
	}
	public void setOperation(Character operation) {
		this.operation = operation;
	}
	public void setOperandTwo(Double num) {
		this.operandtwo = num;
	}
	
	public void performOperation() {

		if( operandone == null) {
			System.out.println("Need first operation");

		}else if (operandtwo == null) {
			System.out.println("Need second operation");

		}
		else if (operation == null) {
			System.out.println("Need operand");

		}
		if(operation == '+') {
			this.total=operandone+operandtwo;
		}else if(operation == '-') {
			this.total = operandone - operandtwo;
		}

	}
	public Double getResults() {
		return total;
	}
	

}
