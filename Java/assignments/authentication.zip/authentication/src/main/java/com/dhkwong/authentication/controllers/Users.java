package com.dhkwong.authentication.controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dhkwong.authentication.models.User;
import com.dhkwong.authentication.services.UserService;

@Controller
public class Users {
	private final UserService userService;

	public Users(UserService userService) {
		this.userService = userService;
	}

	@RequestMapping("/registration")
	public String registerForm(@ModelAttribute("user") User user) {
		return "/views/registrationPage.jsp";
	}

	@RequestMapping("/login")
	public String login() {
		return "/views/loginPage.jsp";
	}

	@RequestMapping(value = "/registration", method = RequestMethod.POST)
	public String registerUser(@Valid @ModelAttribute("user") User user, BindingResult result, HttpSession session) {
		if (userService.findByEmail(user.getEmail()) == null) {// if there's no user, we can continue to create a user

			if (user.getPassword().equals(user.getPasswordConfirmation())) {// if password and confirmation are the same,
																		// create user
				User newuser = userService.registerUser(user);
				session.setAttribute("userid", newuser.getId());// save uId into session
				System.out.println("registered: " + newuser.getEmail());
				

				return "redirect:/home";//redirect to /home route to assign user to Model for displaying to the page
			} else {
				return "/views/registrationPage.jsp";// else, display original registration page
			}
		} else { // if there's already a user with that email, display reg page
			return "/views/registrationPage.jsp";
		}

	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String loginUser(@RequestParam("email") String email, @RequestParam("password") String password, Model model,
			HttpSession session) {
		if(userService.authenticateUser(email, password)) { //if true, set session
			session.setAttribute("userid", userService.findByEmail(email).getId());
			return "redirect:/home";
		}else {
			
			model.addAttribute("error", "invalid login");
			return "/views/loginPage.jsp";
		}
		
		// if the user is authenticated, save their user id in session
		// else, add error messages and return the login page
	}

	@RequestMapping("/home")
	public String home(HttpSession session, Model model) {
		// get user from session, save them in the model and return the home page
		if(session.getAttribute("userid")== null) {//if someone is NOT already logged in
			
			return "redirect:/login";//go back to login
		}else {
			model.addAttribute("user", userService.findById((Long)session.getAttribute("userid")));//pulls user by id to model
			return "/views/homePage.jsp"; //else, they're logged in and we can show them their homepage
		}
		
	}

	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/login";
		// invalidate session
		// redirect to login page
	}
}
