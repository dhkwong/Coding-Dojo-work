package com.dhkwong.authentication.services;

import java.util.Optional;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.stereotype.Service;

import com.dhkwong.authentication.models.User;
import com.dhkwong.authentication.repositories.UserRepository;

@Service
public class UserService {
	private final UserRepository urepo;

	public UserService(UserRepository urepo) {
		this.urepo = urepo;

	}

	public User registerUser(User user) {
		String hashed = BCrypt.hashpw(user.getPassword(), BCrypt.gensalt());
		user.setPassword(hashed);
		return urepo.save(user);

	}

	public User findByEmail(String email) {
		return urepo.findByEmail(email);
	}

	public User findById(Long id) {
		Optional<User> ouser = urepo.findById(id);
		if (ouser.isPresent()) {
			return ouser.get();

		} else {
			return null;
		}
	}

	public boolean authenticateUser(String email, String password) {
		User user = urepo.findByEmail(email);
		if (user == null) {
			return false;
		} else {
			if (BCrypt.checkpw(password, user.getPassword())) {
				return true;
			} else {
				return false;
			}
		}
	}
}
