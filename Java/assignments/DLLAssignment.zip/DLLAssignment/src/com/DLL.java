package com;

public class DLL {
	Node head = null;
	Node tail = null;

	public void printValuesBackward() {
		Node runner = tail;
		while (runner.previous != null) {
			System.out.println(runner.value);
		}
	}

	public void pop() {
		tail = tail.previous;
		tail.next = null;
	}

	public boolean contains(int value) {
		Node runner = head;
		while (runner != null) {
			if (runner.value == value) {
				return true;
			} else {
				runner = runner.next;
			}
		}
		return false;
	}
	public int size() {
		int size = 0;
		Node runner = head;
		while (runner != null) {
			size++;
			runner = runner.next;
		}
		return size;
	}

	public void push(Node newNode) {
		// if there is no head in the list, aka, an empty list, we set the newNode to be
		// the head and tail of the list
		if (this.head == null) {
			this.head = newNode;
			this.tail = newNode;
			return;
		}

		// first find the lastNode in the list
		// then, set the lastNode's next to be the newNode;copy
		// then, we have to set the previous of the lastNode to the lastNode that we
		// found previously.
		// finally, set the list's tail to be the node that we have added
		Node lastNode = this.tail;
		lastNode.next = newNode;
		newNode.previous = lastNode;
		this.tail = newNode;
	}

	public void printValuesForward() {
		// find the first node, aka head.
		Node current = this.head;

		// while the current node exists...
		while (current != null) {
			// print it's value
			System.out.println(current.value);
			// and move on to it's next node.
			current = current.next;
		}
	}
}
