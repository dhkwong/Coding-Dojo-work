from django.apps import AppConfig


class PhotoprojectAppConfig(AppConfig):
    name = 'photoproject_app'
