from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.index),
    url(r'^checkout$', views.checkout),
    url(r'^checkoutprocess/(?P<id>\d+)/(?P<quantity>\d+)$', views.checkoutprocess),
    url(r'^thankyou', views.thankyou),
]