from django.shortcuts import render, redirect
from .models import Order, Product
from django.http import HttpResponseRedirect
def index(request):
    context = {
        "all_products": Product.objects.all()
    }
    return render(request, "store/index.html", context)

def checkout(request):
    quantity= int(request.POST["quantity"])
    productid=request.POST['id']
    product = Product.objects.get(id=productid)
    price = float(product.price)
    
    total_charge = quantity * price
    content = {
        "product":product,
        "price":price,
        "quantity":quantity,
        "total_charge":total_charge
    }

    return render(request, "store/checkout.html", content) 
    
    
    
    
def checkoutprocess(request, id, quantity):
    product = Product.objects.get(id=id)
    price = float(product.price)
    quantity = float(quantity)
    total_charge = quantity * price
    order = Order.objects.create(quantity_ordered=quantity, total_price=total_charge)
    print(order.total_price)
    print(Order.objects.all())
    return redirect('/thankyou') #redirect to ('/thankyou') page

def thankyou(request):

    return render(request, 'store/thankyou.html')