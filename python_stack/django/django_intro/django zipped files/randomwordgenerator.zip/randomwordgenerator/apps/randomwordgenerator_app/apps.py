from django.apps import AppConfig


class RandomwordgeneratorAppConfig(AppConfig):
    name = 'randomwordgenerator_app'
