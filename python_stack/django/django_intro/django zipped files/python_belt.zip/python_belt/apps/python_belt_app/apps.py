from django.apps import AppConfig


class PythonBeltAppConfig(AppConfig):
    name = 'python_belt_app'
