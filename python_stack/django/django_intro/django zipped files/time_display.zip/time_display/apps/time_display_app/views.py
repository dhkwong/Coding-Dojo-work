from django.shortcuts import render, HttpResponse
import datetime

def index(request):
    time = datetime.datetime.now()
    # currtime = {
    #     "time":time
    # }
    print(time)
    return render(request,"time_display_app/index.html", {"currtime":time})