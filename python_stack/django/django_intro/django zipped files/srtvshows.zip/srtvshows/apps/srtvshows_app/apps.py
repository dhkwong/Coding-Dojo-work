from django.apps import AppConfig


class SrtvshowsAppConfig(AppConfig):
    name = 'srtvshows_app'
