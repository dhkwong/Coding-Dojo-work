from flask import Flask, render_template, request, redirect # added request
            

app = Flask(__name__)
# our index route will handle rendering our form
@app.route("/play/<mult>/<color>")
def index(mult,color):
    return render_template("index.html", blue_boxes="style='background-color:"+color+ "; height:200px; width:10%; margin:2%; display:inline-block;'" , times=int(mult))
#<div style='background-color:blue; height:200px; width:200px; display-style:inline-block;'></div>

if __name__ == "__main__":
    app.run(debug=True)


